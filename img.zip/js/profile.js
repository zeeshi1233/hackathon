import { app, auth, db, storage } from './firebas.js'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-auth.js";
import { setDoc, doc, query, where, onSnapshot, collection, addDoc, updateDoc,orderBy } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-firestore.js";
import { ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-storage.js";

let userId=localStorage.getItem("userId");
const show_user = () => {
    var userProfile=JSON.parse(localStorage.getItem("userProfile"))
  onAuthStateChanged(auth, (user) => {
    if (user) {
      onSnapshot(collection(db, "users"), (data) => {
        data.docChanges().forEach((change) => {
          if (change.doc.data().user===userProfile.id) {
         document.getElementById("user_name").innerHTML=user.email
         document.getElementById("user_name").innerHTML=change.doc.data().name
         document.getElementById("user_pic").src=userProfile.pic
          }
        })
      });

    } else {
      window.location.href = "login.html"
    }
    
  });
}
show_user()